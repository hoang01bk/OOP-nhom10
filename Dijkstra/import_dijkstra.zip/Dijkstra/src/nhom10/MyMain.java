package nhom10;

public class MyMain {
	public static void main(String[] args) {
		new MyFrame("Chương trình mô phỏng thuật toán Dijkstra");
	}
}
